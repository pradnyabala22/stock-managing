package controller.commands;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import model.BetterIModel;
import view.BetterIView;

/**
 * CrossOver class that implements ICommand and executes the crossover command for a
 * given stock. Interacts with model for specific calculations and uses the view to interact
 * with the user.
 */
public class CrossOver implements ICommand {

  /**
   * Constructs CrossOver command with given view.
   *
   * @param view represents the view component of the program.
   */
  public CrossOver(BetterIView view) {
    BetterIView view1 = Objects.requireNonNull(view);
  }

  @Override
  public void run(BetterIModel model, BetterIView view) {
    boolean continueInput = true;

    while (continueInput) {
      view.writeMessage("Input ticker symbol: ");
      String ticker = view.getInput().trim();
      if (ticker.equalsIgnoreCase("q")) {
        return;
      }

      view.writeMessage("Enter the start date.");
      String startDate = view.getDateInput();
      if (startDate.equalsIgnoreCase("q")) {
        return;
      }

      view.writeMessage("Enter the end date.");
      String endDate = view.getDateInput();
      if (endDate.equalsIgnoreCase("q")) {
        return;
      }

      view.writeMessage("Enter the period of days you want to check for: ");
      String numDays = view.getInput().trim();
      if (numDays.equalsIgnoreCase("q")) {
        return;
      }

      if (!ticker.isEmpty() && !startDate.isEmpty() && !endDate.isEmpty() && !numDays.isEmpty()) {
        try {
          SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
          format.setLenient(false);
          Date startParse = format.parse(startDate);
          Date endParse = format.parse(endDate);

          if (startParse.after(endParse)) {
            throw new IllegalArgumentException("Invalid date range. The start " +
                    "date must be before the end date.");
          }

          String apiKey = "JTQFLMKHAVWUSUC4";
          String destinationFolder = "res/res/stocks";
          model.loadData(ticker, destinationFolder, apiKey);

          if (!model.doesTickerExist(ticker)) {
            throw new IllegalArgumentException("Ticker symbol does not exist.");
          }

          int numDaysInt = Integer.parseInt(numDays);

          if (numDaysInt < 1) {
            throw new IllegalArgumentException("The number of days must be a positive integer.");
          }

          List<String> crossovers = model.getCrossOver(ticker, startDate, endDate, numDaysInt);

          if (crossovers.isEmpty()) {
            view.writeMessage("No crossovers for this period.\n");
          } else {
            view.writeMessage("Crossovers: " + String.join(", ", crossovers) + "\n");
          }
        } catch (NumberFormatException e) {
          view.writeMessage("Invalid format for number of days.\n");
        } catch (ParseException e) {
          view.writeMessage("Date doesn't exist, you must enter a valid date for this month.\n");
        } catch (IllegalArgumentException e) {
          view.writeMessage(e.getMessage() + "\n");
        } catch (Exception e) {
          view.writeMessage("An error occurred: " + e.getMessage() + "\n");
        }
      } else {
        view.writeMessage("Invalid input.\n");
      }

      continueInput = false;
    }
  }
}
