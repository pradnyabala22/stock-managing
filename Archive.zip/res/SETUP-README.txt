How to run the program from a JAR file:
1. Go to the place where the hw is saved
2. Go into the res folder and then in terminal type "java -jar assignment6.2.jar" and
press enter for the GUI interface to run.
3. If you want the text based interface to run like last time, type in
"java -jar assignment6.2.jar -text" and press enter for it to run.
4. If you type any other command line other than this, it will not run the program.

Specification:
Create, save, and load the portfolio before you check the performance of it.